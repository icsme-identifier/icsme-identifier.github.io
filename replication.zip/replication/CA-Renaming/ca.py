import sys
import time
from base import Base


if __name__ == '__main__':
    if len(sys.argv) == 1:
        print('please input the project path')
    else:
        print('project path: ' + sys.argv[1])
        path = sys.argv[1]
        sd = Base(path)
        start_time = time.time()
        sd.process()
        print("--- %s seconds ---" % (time.time() - start_time))
