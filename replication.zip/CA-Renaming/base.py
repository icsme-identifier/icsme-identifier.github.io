import json
import os
import csv

import pandas as pd
from lxml import etree
from subprocess import call


# http://stackoverflow.com/questions/14596884/remove-text-between-and-in-python
def remove_brackets(my_string):
    ret = ''
    skip1c = 0
    skip2c = 0
    for i in my_string:
        if i == '[':
            skip1c += 1
        elif i == '(':
            skip2c += 1
        elif i == ']' and skip1c > 0:
            skip1c -= 1
        elif i == ')' and skip2c > 0:
            skip2c -= 1
        elif skip1c == 0 and skip2c == 0:
            ret += i
    return ret


class Base:
    def __init__(self, project_path):
        if project_path[-1] != '/':
            project_path += '/'
        self.repo_dir = project_path
        self.project = project_path.split('/')[-2]
        self.source_path = 'data/' + self.project + '/source/'
        self.method_path = 'data/' + self.project + '/method/'
        self.meta_path = 'data/' + self.project + '/meta/'
        self.result_path = 'data/' + self.project + '/result/'
        self.method_js = None
        self.method_csv = None
        self.result_csv = None
        self.decl_js = None
        self.class_o = None
        self.class_all = None
        if not os.path.exists('data/' + self.project):
            os.makedirs(self.meta_path)
            os.makedirs(self.source_path)
            os.makedirs(self.result_path)
            os.makedirs(self.method_path)

    # Parse java code to xml with srcml
    def parse_to_xml(self):
        srcml = open('srcml.conf', 'r').readline().strip()
        for directory, sub_dirs, files in os.walk(self.repo_dir, topdown=False):
            for name in files:
                if name.endswith('.java'):
                    if not os.path.exists(directory.replace(self.repo_dir, self.source_path)):
                        os.makedirs(directory.replace(self.repo_dir, self.source_path))
                    cmd = srcml + ' "' + os.path.join(directory, name) + '" -o "' + os.path.join(
                        directory.replace(self.repo_dir, self.source_path), name.replace('.java', '.xml')) + '"'
                    call(cmd, shell=True)

    def extract_var(self, method_xml, namespaces, decl_js, method_js, method_csv, class_index, class_name, file_path,
                    method_index):
        type_xml = method_xml.xpath('./src:type', namespaces=namespaces)
        name_xml = method_xml.xpath('./src:name', namespaces=namespaces)
        return_xml = method_xml.xpath('.//src:return/src:expr/src:name',
                                      namespaces=namespaces)
        if len(type_xml) > 0 and len(name_xml) > 0:
            method_type = ''.join(type_xml[0].itertext()).replace(' ', '')
            method_name = ''.join(name_xml[0].itertext()).replace(' ', '')
            if len(return_xml) > 0:
                method_return = ''.join(return_xml[-1].itertext()).replace(' ', '')
            else:
                method_return = ''

            decl_js[str(method_index)] = {}
            no_tags = etree.tostring(method_xml, encoding='utf8', method='text').strip()
            tmp_para = ''
            para_no = 0
            # print etree.tostring(function, pretty_print=True)
            # get parameter and all variables defined in the function
            parameters = method_xml.xpath('./src:parameter_list/src:parameter', namespaces=namespaces)
            for parameter in parameters:
                para_type_xml = parameter.xpath('./src:decl/src:type', namespaces=namespaces)
                para_name_xml = parameter.xpath('./src:decl/src:name', namespaces=namespaces)
                if len(para_name_xml) > 0 and len(para_type_xml) > 0:
                    para_name = ''.join(para_name_xml[0].itertext()).replace(' ', '')
                    para_type = ''.join(para_type_xml[0].itertext()).replace(' ', '')
                    while para_name[-2:] == '[]':
                        para_name = para_name[:-2]
                        para_type += '[]'
                    tmp_para = tmp_para + para_type + ' ' + para_name + ','
                    para_no += 1
                    decl_js[str(method_index)][para_name] = para_type
            method_block = method_xml.xpath('./src:block', namespaces=namespaces)
            if len(method_block) == 0:
                method_block = method_xml.xpath('./src:throws/src:block', namespaces=namespaces)
                if len(method_block) == 0:
                    return
            method_block = method_block[0]
            catch_parameters = method_block.xpath('.//src:parameter_list/src:parameter', namespaces=namespaces)
            for parameter in catch_parameters:
                para_type_xml = parameter.xpath('./src:decl/src:type', namespaces=namespaces)
                para_name_xml = parameter.xpath('./src:decl/src:name', namespaces=namespaces)
                if len(para_name_xml) > 0 and len(para_type_xml) > 0:
                    para_name = ''.join(para_name_xml[0].itertext()).replace(' ', '')
                    para_type = ''.join(para_type_xml[0].itertext()).replace(' ', '')
                    while para_name[-2:] == '[]':
                        para_name = para_name[:-2]
                        para_type += '[]'
                    decl_js[str(method_index)][para_name] = para_type
            declarations = method_xml.xpath('.//src:decl_stmt', namespaces=namespaces)
            for declaration in declarations:
                decl_type_xml = declaration.xpath('./src:decl/src:type/src:name', namespaces=namespaces)
                for decl_name_xml in declaration.xpath('./src:decl/src:name', namespaces=namespaces):
                    decl_name = ''.join(decl_name_xml.itertext()).replace(' ', '')
                    decl_type = ''.join(decl_type_xml[0].itertext()).replace(' ', '')
                    while decl_name[-2:] == '[]':
                        decl_name = decl_name[:-2]
                        decl_type += '[]'
                    decl_js[str(method_index)][decl_name] = decl_type
            method_js[str(method_index)] = {'name': method_name, 'type': method_type, 'para_no': para_no,
                                            'return': method_return, 'class_index': class_index,
                                            'class_name': class_name, 'file_path': file_path,
                                            'method_path': method_name + '(' + tmp_para[:-1] + ')'}
            method_csv.writerow([method_index, method_name, method_type, para_no, method_return, class_index,
                                 class_name, file_path, method_name + '(' + tmp_para[:-1] + ')'])
            f = open(self.method_path + str(method_index) + '.java', 'w')
            f.write(no_tags.decode('utf-8'))
            f.close()

    # extract assignments of methods
    def extract_method_asgment(self, method_xml, namespaces, asgn_csv, method_id):
        for decl_stmt in method_xml.xpath('.//src:decl[src:init[contains(.,"=")]]',
                                          namespaces=namespaces):
            init_expr = decl_stmt.xpath('.//src:init/src:expr', namespaces=namespaces)
            if init_expr:
                op = init_expr[0].xpath('./src:operator', namespaces=namespaces)
                if op and op[0].text == 'new':
                    pass  # print('class', ''.join(decl_stmt.itertext()))
                else:
                    call = init_expr[0].xpath('./src:call', namespaces=namespaces)
                    if call:
                        call_stmt = ''.join(decl_stmt.itertext())
                        var = call_stmt.split('=')[0].strip().split(' ')[-1]
                        assignment = call_stmt.split('=')[1].strip()
                        asgn_csv.writerow([method_id, var, assignment, 'decl_call'])
                    else:
                        operators = init_expr[0].xpath('./src:operator', namespaces=namespaces)
                        ops = [op.text for op in operators if op.text not in ['.', '=']]
                        literal = init_expr[0].xpath('./src:literal', namespaces=namespaces)
                        block = init_expr[0].xpath('./src:block', namespaces=namespaces)
                        if (len(ops) + len(literal) + len(block)) == 0:
                            name_stmt = ''.join(decl_stmt.itertext())
                            var = name_stmt.split('=')[0].strip().split(' ')[-1]
                            assignment = name_stmt.split('=')[1].strip()
                            asgn_csv.writerow([method_id, var, assignment, 'decl_name'])
            else:
                pass  # print('others', ''.join(decl_stmt.itertext()))
        for expr_stmt in method_xml.xpath('.//src:expr[src:operator[.="="]]', namespaces=namespaces):
            calls = expr_stmt.xpath('./src:call', namespaces=namespaces)
            if len(calls) > 1:
                pass  # print('other call', ''.join(calls[0].itertext()), ''.join(expr_stmt.itertext()))
            elif len(calls) == 1:
                operators = expr_stmt.xpath('./src:operator', namespaces=namespaces)
                ops = [op.text for op in operators if op.text not in ['.', '=']]
                if len(ops) > 0:
                    pass  # print('other call2', ops, ''.join(calls[0].itertext()), ''.join(expr_stmt.itertext()))
                else:
                    call_stmt = ''.join(expr_stmt.itertext())
                    var = call_stmt.split('=')[0].strip().split(' ')[-1]
                    assignment = call_stmt.split('=')[1].strip()
                    asgn_csv.writerow([method_id, var, assignment, 'assign_call'])
            else:
                names = expr_stmt.xpath('./src:name', namespaces=namespaces)
                if len(names) > 1:
                    name_stmt = ''.join(expr_stmt.itertext())
                    var = name_stmt.split('=')[0].strip().split(' ')[-1]
                    assignment = name_stmt.split('=')[1].strip()
                    asgn_csv.writerow([method_id, var, assignment, 'assign_name'])
                else:
                    pass  # print(''.join(expr_stmt.itertext()))

    # Parse XML and extract the meta information of the methods
    def extract_methods_meta(self):
        decl_js = {}
        method_js = {}
        method_file = open(self.meta_path + self.project + '_method.csv', 'w')
        method_csv = csv.writer(method_file, delimiter=',')
        method_csv.writerow(['method_id', 'name', 'type', 'para_no', 'return', 'class_index', 'class_name', 'file_path',
                             'method_path'])
        asgn_file = open(self.meta_path + self.project + '_asgn.csv', 'w')
        asgn_csv = csv.writer(asgn_file, delimiter=',')
        asgn_csv.writerow(['method_id', 'variable', 'assignment', 'type'])
        class_outer = {}
        class_all = {}
        file_index = 1
        class_index = 0
        method_index = 0
        for directory, sub_dirs, files in os.walk(self.source_path, topdown=False):
            for name in files:
                if name.endswith('.xml'):
                    p = etree.XMLParser(huge_tree=True)
                    xml_tree = etree.parse(os.path.join(directory, name), p)
                    namespaces = {'src': 'http://www.srcML.org/srcML/src'}
                    for class_xml in xml_tree.xpath('/src:unit/src:class', namespaces=namespaces):
                        class_index += 1
                        class_name = ''.join(class_xml.xpath('./src:name', namespaces=namespaces)[0].itertext())
                        class_outer[class_name] = {'index': class_index}
                        class_all[class_index] = {'name': class_name}
                        for extends in class_xml.xpath('./src:super/src:extends/src:name', namespaces=namespaces):
                            class_outer[class_name]['extends'] = extends.text
                            class_all[class_index]['extends'] = extends.text
                        class_all[class_index]['vars'] = []
                        class_all[class_index]['var_types'] = []
                        for var in class_xml.xpath('./src:block/src:decl_stmt/src:decl', namespaces=namespaces):
                            var_name = var.xpath('./src:name', namespaces=namespaces)
                            var_type = var.xpath('./src:type', namespaces=namespaces)
                            if len(var_name) > 0 and len(var_type) > 0:
                                class_all[class_index]['var_types']. \
                                    append(''.join(var_type[0].itertext()).replace(' ', ''))
                                class_all[class_index]['vars'].append(''.join(var_name[0].itertext()).replace(' ', ''))
                        for function in class_xml.xpath('./src:block/src:function', namespaces=namespaces):
                            method_index += 1
                            self.extract_var(function, namespaces, decl_js, method_js, method_csv, class_index,
                                             class_name, os.path.join(directory, name).replace('.xml', '.java')
                                             .replace(self.source_path, ''), method_index)
                            self.extract_method_asgment(function, namespaces, asgn_csv, method_index)

                        class_all[class_index]['file'] = file_index
                        for inner_class in class_xml.xpath('.//src:class', namespaces=namespaces):
                            class_index += 1
                            class_name_xml = inner_class.xpath('./src:name', namespaces=namespaces)
                            if len(class_name_xml) > 0:
                                class_name = ''.join(class_name_xml[0].itertext())
                            else:
                                class_name_xml = inner_class.xpath('./src:super/src:name', namespaces=namespaces)
                                if len(class_name_xml) > 0:
                                    class_name = ''.join(class_name_xml[0].itertext())
                                else:
                                    continue
                            class_all[class_index] = {'name': class_name}
                            for extends in inner_class.xpath('./src:super/src:extends/src:name', namespaces=namespaces):
                                class_all[class_index]['extends'] = ''.join(extends.itertext())
                            class_all[class_index]['vars'] = []
                            class_all[class_index]['var_types'] = []
                            for var in inner_class.xpath('./src:block/src:decl_stmt/src:decl', namespaces=namespaces):
                                var_name = var.xpath('./src:name', namespaces=namespaces)
                                var_type = var.xpath('./src:type', namespaces=namespaces)
                                if len(var_name) > 0 and len(var_type) > 0:
                                    class_all[class_index]['var_types']. \
                                        append(''.join(var_type[0].itertext()).replace(' ', ''))
                                    class_all[class_index]['vars'].append(
                                        ''.join(var_name[0].itertext()).replace(' ', ''))
                            for function in inner_class.xpath('./src:block/src:function', namespaces=namespaces):
                                method_index += 1
                                type_xml = function.xpath('./src:type', namespaces=namespaces)
                                name_xml = function.xpath('./src:name', namespaces=namespaces)
                                if len(type_xml) > 0 and len(name_xml) > 0:
                                    method_type = ''.join(type_xml[0].itertext()).replace(' ', '')
                                    method_name = ''.join(name_xml[0].itertext()).replace(' ', '')
                                    return_xml = function.xpath('./src:block/src:return/src:expr/src:name',
                                                                namespaces=namespaces)
                                    if len(return_xml) > 0:
                                        method_return = ''.join(return_xml[0].itertext()).replace(' ', '')
                                    else:
                                        method_return = ''
                                    method_js[str(method_index)] = {'name': method_name, 'type': method_type,
                                                                    'return': method_return, 'class': class_index,
                                                                    'path': os.path.join(directory, name)}
                                    self.extract_method_asgment(function, namespaces, asgn_csv, method_index)
                                    self.extract_var(function, namespaces, decl_js, method_js, method_csv, class_index,
                                                     class_name, os.path.join(directory, name).replace('.xml', '.java')
                                                     .replace(self.source_path, ''), method_index)
                            class_all[class_index]['file'] = file_index
                    file_index += 1
        # print(class_all)
        for key, value in class_all.items():
            tmp_class = value
            while ('extends' in tmp_class) and (tmp_class['extends'] is not None) and (tmp_class['extends'] in class_outer):
                tmp_class = class_all[class_outer[tmp_class['extends']]['index']]
                value['vars'] += tmp_class['vars']
                value['var_types'] += tmp_class['var_types']
        json.dump(decl_js, open(self.meta_path + self.project + '_decl.json', 'w'))
        json.dump(class_outer, open(self.meta_path + self.project + '_class_o.json', 'w'))
        json.dump(class_all, open(self.meta_path + self.project + '_class.json', 'w'))
        json.dump(method_js, open(self.meta_path + self.project + '_method.json', 'w'))
        asgn_file.close()
        method_file.close()

    # give recommendations for each variable in the methods
    def recommend_row(self, row):
        method_id = str(int(row['method_id']))
        if row['variable'] in self.decl_js[method_id]:
            if '.' not in row['variable']:
                row['var_type'] = self.decl_js[method_id][row['variable']]
        if '.' not in row['assignment']:
            if '(' in row['assignment']:
                class_id = self.method_js[method_id]['class_index']
                method_name = row['assignment'].split('(')[0]
                func = self.method_csv[(self.method_csv['class_index'] == int(class_id)) &
                                       (self.method_csv['name'] == method_name)]
                if len(func) > 0:
                    row['return_name'] = func['return'].iat[0]
                    row['return_type'] = func['type'].iat[0]
        else:
            new_class_id = None
            if row['assignment'].strip()[0] == '(':
                method_type = row['assignment'].split(')')[0].strip()[1:]
                method_rest = ')'.join(row['assignment'].split(')')[1:])
                method_name = method_rest.split('(')[0].split('.')[-1]
                method_parent = method_rest.split('(')[0].split('.')[0]
                # print(method_id, method_name, method_parent)
                if method_parent in self.decl_js[str(method_id)]:
                    var_class = self.decl_js[str(method_id)][method_parent]
                    if var_class in self.class_o:
                        new_class_id = self.class_o[var_class]['index']

                elif method_parent in self.class_o:
                    new_class_id = self.class_o[method_parent]['index']

                if new_class_id:
                    left_index = row['assignment'].find('(')
                    right_index = row['assignment'].rfind(')')
                    parameters = row['assignment'][(left_index + 1):right_index].strip()
                    if not parameters:
                        parameter_no = 0
                    else:
                        parameter_no = remove_brackets(parameters).count(',')
                    func = self.method_csv[(self.method_csv['class_index'] == int(new_class_id)) &
                                           (self.method_csv['name'] == method_name) &
                                           (self.method_csv['para_no'] == parameter_no)]
                    if len(func) > 0:
                        row['return_name'] = str(func['return'].iat[0]).split('.')[-1]
                        row['return_type'] = method_type

            elif '(' in row['assignment']:
                if row['assignment'].split('(')[0].count('.') == 1:
                    method_name = row['assignment'].split('(')[0].split('.')[-1]
                    method_parent = row['assignment'].split('(')[0].split('.')[0]

                    if method_parent in self.decl_js[str(method_id)]:
                        var_class = self.decl_js[str(method_id)][method_parent]
                        if var_class in self.class_o:
                            new_class_id = self.class_o[var_class]['index']
                    elif method_parent in self.class_o:
                        new_class_id = self.class_o[method_parent]['index']
                    if new_class_id:
                        left_index = row['assignment'].find('(')
                        right_index = row['assignment'].rfind(')')
                        parameters = row['assignment'][(left_index + 1):right_index].strip()
                        if not parameters:
                            parameter_no = 0
                        else:
                            parameter_no = remove_brackets(parameters).count(',')
                        '''
                        if row['assignment'].split('(')[1].strip()[0] == ')':
                            parameter_no = 0
                        else:
                            parameter_no = row['assignment'].split('(')[1].count(',') + 1
                            # print(row['assignment'].split('(')[1], parameter_no)
                        '''
                        func = self.method_csv[(self.method_csv['class_index'] == int(new_class_id)) &
                                               (self.method_csv['name'] == method_name) &
                                               (self.method_csv['para_no'] == parameter_no)]
                        if len(func) > 0:
                            row['return_name'] = str(func['return'].iat[0]).split('.')[-1]
                            row['return_type'] = func['type'].iat[0]
            else:
                if row['assignment'].split('(')[0].count('.') == 1:
                    assign_name = row['assignment'].split('(')[0].split('.')[-1]
                    assign_parent = row['assignment'].split('(')[0].split('.')[0]
                    if assign_parent in self.decl_js[str(method_id)]:
                        var_class = self.decl_js[str(method_id)][assign_parent]
                        if var_class in self.class_o:
                            new_class_id = self.class_o[var_class]['index']
                            vars = self.class_all[str(new_class_id)]['vars']
                            var_types = self.class_all[str(new_class_id)]['var_types']
                            if assign_name in vars:
                                row['return_name'] = assign_name
                                row['return_type'] = var_types[vars.index(assign_name)]
        return row

    # give recommendations
    def recommend(self):
        self.method_js = json.load(open(self.meta_path + self.project + '_method.json'))
        self.decl_js = json.load(open(self.meta_path + self.project + '_decl.json'))
        self.class_o = json.load(open(self.meta_path + self.project + '_class_o.json'))
        self.class_all = json.load(open(self.meta_path + self.project + '_class.json'))
        self.method_csv = pd.read_csv(self.meta_path + self.project + '_method.csv')
        df = pd.read_csv(self.meta_path + self.project + '_asgn.csv')
        df = df.apply(self.recommend_row, axis=1)
        df.to_csv(self.meta_path + self.project + '_asgn.csv', index=None)

    def clean_helper(self, row):
        forbidden_list = list(self.decl_js[str(int(row['method_id']))].keys()) + \
                         self.class_all[str(self.method_js[str(int(row['method_id']))]['class_index'])]['vars']
        if row['return_name'] in forbidden_list:
            row['return_name'] = ''
        return row

    def save_result(self, group):
        suggestions = group['return_name'].tolist()
        suggestion = max(set(suggestions), key=suggestions.count)
        if '[' not in suggestion:
            method = self.method_js[str(int(group['method_id'].iat[0]))]
            self.result_csv.writerow([method['file_path'], method['class_name'], method['method_path'],
                                      group['variable'].iat[0], suggestion])

    # clean up the results
    def clean(self):
        self.method_js = json.load(open(self.meta_path + self.project + '_method.json'))
        self.class_all = json.load(open(self.meta_path + self.project + '_class.json'))
        self.decl_js = json.load(open(self.meta_path + self.project + '_decl.json'))
        df = pd.read_csv(self.meta_path + self.project + '_asgn.csv')
        df = df[df['return_type'] == df['var_type']]
        df = df.apply(self.clean_helper, axis=1)
        df = df[(df['return_name'] != '') & (df['return_name'].notnull())]
        result_file = open(self.result_path + self.project + '.csv', 'w')
        self.result_csv = csv.writer(result_file, delimiter=',')
        self.result_csv.writerow(['file', 'class', 'method', 'variable', 'suggestion'])
        df.groupby(['method_id', 'variable']).apply(self.save_result)

    def process(self):
        print('converting source code to xml (1/3)')
        self.parse_to_xml()
        print('extracting methods information (2/3)')
        self.extract_methods_meta()
        print('generating recommendations (3/3)')
        self.recommend()
        self.clean()
