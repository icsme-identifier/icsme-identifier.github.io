import ast
import csv
import json
import os
import threading
from collections import Counter

try:
    import _thread
except ImportError:
    import _dummy_thread as _thread
import pandas as pd
from lxml import etree
from subprocess import call


class SynonymDetector:
    def __init__(self, project_path):
        if project_path[-1] != '/':
            project_path += '/'
        self.repo_dir = project_path
        self.project = project_path.split('/')[-2]
        print('Project: ' + self.project)
        self.meta_path = 'data/' + self.project + '/meta/'
        self.source_path = 'data/' + self.project + '/source/'
        self.inter_path = 'data/' + self.project + '/intermediate/'
        self.method_path = 'data/' + self.project + '/intermediate/method/'
        self.decl_path = 'data/' + self.project + '/intermediate/decl/'
        self.trigram_path = 'data/' + self.project + '/intermediate/trigram/'
        self.result_path = 'data/' + self.project + '/result/'
        self.rest = None
        self.indicator = None
        self.meta_js = None
        self.decl_js = None
        self.class_js = None
        if not os.path.exists('data/' + self.project):
            os.makedirs(self.meta_path)
            os.makedirs(self.source_path)
            os.makedirs(self.inter_path)
            os.makedirs(self.method_path)
            os.makedirs(self.decl_path)
            os.makedirs(self.trigram_path)
            os.makedirs(self.result_path)

    # Parse java code to xml with srcml
    def parse_to_xml(self):
        srcml = open('srcml.conf', 'r').readline().strip()
        for directory, sub_dirs, files in os.walk(self.repo_dir, topdown=False):
            for name in files:
                if name.endswith('.java'):
                    if not os.path.exists(directory.replace(self.repo_dir, self.source_path)):
                        os.makedirs(directory.replace(self.repo_dir, self.source_path))
                    cmd = srcml + ' "' + os.path.join(directory, name) + '" -o "' + os.path.join(
                        directory.replace(self.repo_dir, self.source_path), name.replace('.java', '.xml')) + '"'
                    call(cmd, shell=True)

    # Thread helping extracte methods and variables
    def extract_worker(self, method_xml, namespaces, decl_js, meta_js, class_index, class_name, file_path,
                       method_index):
        func_name = ''.join(method_xml.xpath('./src:name', namespaces=namespaces)[0].itertext())
        decl_js[str(method_index)] = {}
        no_tags = etree.tostring(method_xml, encoding='utf8', method='text').strip()
        tmp_para = ''
        # print etree.tostring(function, pretty_print=True)
        # get parameter and all variables defined in the function
        parameters = method_xml.xpath('./src:parameter_list/src:parameter', namespaces=namespaces)
        for parameter in parameters:
            para_type_xml = parameter.xpath('./src:decl/src:type', namespaces=namespaces)
            para_name_xml = parameter.xpath('./src:decl/src:name', namespaces=namespaces)
            if len(para_name_xml) > 0 and len(para_type_xml) > 0:
                para_name = ''.join(para_name_xml[0].itertext()).replace(' ', '')
                para_type = ''.join(para_type_xml[0].itertext()).replace(' ', '')
                while para_name[-2:] == '[]':
                    para_name = para_name[:-2]
                    para_type += '[]'
                tmp_para = tmp_para + para_type + ' ' + para_name + ','
                decl_js[str(method_index)][para_name] = para_type
        method_block = method_xml.xpath('./src:block', namespaces=namespaces)
        if len(method_block) == 0:
            method_block = method_xml.xpath('./src:throws/src:block', namespaces=namespaces)
            if len(method_block) == 0:
                return
        method_block = method_block[0]
        catch_parameters = method_block.xpath('.//src:parameter_list/src:parameter', namespaces=namespaces)
        for parameter in catch_parameters:
            para_type_xml = parameter.xpath('./src:decl/src:type', namespaces=namespaces)
            para_name_xml = parameter.xpath('./src:decl/src:name', namespaces=namespaces)
            if len(para_name_xml) > 0 and len(para_type_xml) > 0:
                para_name = ''.join(para_name_xml[0].itertext()).replace(' ', '')
                para_type = ''.join(para_type_xml[0].itertext()).replace(' ', '')
                while para_name[-2:] == '[]':
                    para_name = para_name[:-2]
                    para_type += '[]'
                decl_js[str(method_index)][para_name] = para_type
        declarations = method_xml.xpath('.//src:decl_stmt', namespaces=namespaces)
        for declaration in declarations:
            decl_type_xml = declaration.xpath('./src:decl/src:type/src:name', namespaces=namespaces)
            for decl_name_xml in declaration.xpath('./src:decl/src:name', namespaces=namespaces):
                decl_name = ''.join(decl_name_xml.itertext()).replace(' ', '')
                decl_type = ''.join(decl_type_xml[0].itertext()).replace(' ', '')
                while decl_name[-2:] == '[]':
                    decl_name = decl_name[:-2]
                    decl_type += '[]'
                decl_js[str(method_index)][decl_name] = decl_type
        f = open(self.method_path + str(method_index) + '.java', 'w')
        f.write(no_tags.decode('utf-8'))
        f.close()
        meta_js[str(method_index)] = {'file_path': file_path.replace('.xml', '.java').replace(self.source_path, ''),
                                      'class_index': class_index, 'class_name': class_name,
                                      'method_path': func_name + '(' + tmp_para[:-1] + ')'}

    # Extract methods and variables
    def extract_methods_variables(self):
        # decl_file = open(self.decl_path + self.project + '.csv', 'w')
        decl_js = {}
        meta_js = {}
        class_outer = {}
        class_all = {}
        file_index = 1
        class_index = 0
        method_index = 0
        threads = []
        for directory, sub_dirs, files in os.walk(self.source_path, topdown=False):
            for name in files:
                if name.endswith('.xml'):
                    p = etree.XMLParser(huge_tree=True)
                    xml_tree = etree.parse(os.path.join(directory, name), p)
                    namespaces = {'src': 'http://www.srcML.org/srcML/src'}
                    for class_xml in xml_tree.xpath('/src:unit/src:class', namespaces=namespaces):
                        class_index += 1
                        class_name = ''.join(class_xml.xpath('./src:name', namespaces=namespaces)[0].itertext())
                        class_outer[class_name] = {'index': class_index}
                        class_all[class_index] = {'name': class_name}
                        for extends in class_xml.xpath('./src:super/src:extends/src:name', namespaces=namespaces):
                            class_outer[class_name]['extends'] = ''.join(extends.itertext())
                            class_all[class_index]['extends'] = ''.join(extends.itertext())
                        class_all[class_index]['vars'] = []
                        for var in class_xml.xpath('./src:block/src:decl_stmt/src:decl/src:name',
                                                   namespaces=namespaces):
                            class_all[class_index]['vars'].append(''.join(var.itertext()))
                        for function in class_xml.xpath('./src:block/src:function', namespaces=namespaces):
                            method_index += 1
                            # self.extract_worker(function, namespaces, decl_js, meta_js, class_index, class_name,
                            #                            os.path.join(directory, name), method_index)
                            #
                            t = threading.Thread(target=self.extract_worker,
                                                 args=(function, namespaces, decl_js, meta_js, class_index, class_name,
                                                       os.path.join(directory, name), method_index,))
                            threads.append(t)
                            t.start()

                        class_all[class_index]['file'] = file_index
                        for inner_class in class_xml.xpath('.//src:class', namespaces=namespaces):
                            class_index += 1
                            class_name_xml = inner_class.xpath('./src:name', namespaces=namespaces)
                            if len(class_name_xml) > 0:
                                class_name = ''.join(class_name_xml[0].itertext())
                            else:
                                class_name_xml = inner_class.xpath('./src:super/src:name', namespaces=namespaces)
                                if len(class_name_xml) > 0:
                                    class_name = ''.join(class_name_xml[0].itertext())
                                else:
                                    continue
                            class_all[class_index] = {'name': class_name}
                            for extends in inner_class.xpath('./src:super/src:extends/src:name', namespaces=namespaces):
                                class_all[class_index]['extends'] = ''.join(extends.itertext())
                            class_all[class_index]['vars'] = []
                            for var in inner_class.xpath('./src:block/src:decl_stmt/src:decl/src:name',
                                                         namespaces=namespaces):
                                class_all[class_index]['vars'].append(''.join(var.itertext()))
                            for function in inner_class.xpath('./src:block/src:function', namespaces=namespaces):
                                method_index += 1
                                # self.extract_worker(function, namespaces, decl_js, meta_js, class_index, class_name,
                                #                     os.path.join(directory, name), method_index)
                                #
                                t = threading.Thread(target=self.extract_worker,
                                                     args=(function, namespaces, decl_js, meta_js, class_index, class_name,
                                                           os.path.join(directory, name), method_index,))
                                threads.append(t)
                                t.start()

                            class_all[class_index]['file'] = file_index
                    file_index += 1
        [t.join() for t in threads]
        for key, value in class_all.items():
            tmp_class = value
            while ('extends' in tmp_class) and (tmp_class['extends'] in class_outer):
                tmp_class = class_all[class_outer[tmp_class['extends']]['index']]
                value['vars'] += tmp_class['vars']
        json.dump(decl_js, open(self.decl_path + self.project + '.json', 'w'))
        json.dump(class_all, open(self.decl_path + self.project + '_class.json', 'w'))
        json.dump(meta_js, open(self.meta_path + self.project + '.json', 'w'))

    # Generate tokens
    def gen_tokens(self):
        cmd = 'java -jar tools/antlr/Tokenize.jar ' + self.method_path
        call(cmd, shell=True)

    # Thread helping generate identifiers
    def gen_identifiers_worker(self, file_path):
        lex_list = [line.strip() for line in open(file_path).readlines()]
        token_list = [line.strip() for line in
                      open(file_path.replace('_lex.tokens', '.tokens')).readlines()]
        f = open(file_path.replace('_lex.tokens', '.id'), 'w')
        f_csv = csv.writer(f, delimiter=',')
        f_csv.writerow(['id'])
        start = 0
        for i, j in enumerate(lex_list):
            if start == 1:
                if j == '102':
                    f_csv.writerow([token_list[i]])
            else:
                if j == '57':
                    start = 1
        f.close()

    # Extract identifiers without method name
    def gen_identifiers_wo_method(self):
        threads = []
        for directory, sub_dirs, files in os.walk(self.method_path, topdown=False):
            for name in files:
                if name.endswith('_lex.tokens'):
                    path = os.path.join(directory, name)
                    t = threading.Thread(target=self.gen_identifiers_worker, args=(path,))
                    threads.append(t)
                    t.start()
        [t.join() for t in threads]

    # Thread helping generate trigrams
    def gen_trigram_worker(self, name, decl_js, f_csv, directory, lock):
        method_no = name[:-3]
        if method_no in decl_js:
            id_df = pd.read_csv(os.path.join(directory, name))
            ids = id_df['id'].tolist()
            types = [decl_js[method_no][id] if id in decl_js[method_no] else None for id in ids]
            for ind in range(0, len(ids) - 2):
                lock.acquire()
                f_csv.writerow([name[:-3], ind, ids[ind], int(types[ind] is not None), types[ind],
                                ids[ind + 1], int(types[ind + 1] is not None), types[ind + 1],
                                ids[ind + 2], int(types[ind + 2] is not None), types[ind + 2]])
                lock.release()

    # Generate tri-grams
    def gen_trigrams(self):
        pd.options.mode.chained_assignment = None
        threads = []
        lock = threading.Lock()
        f = open(self.trigram_path + self.project + '.csv', 'w')
        f_csv = csv.writer(f, delimiter=',')
        f_csv.writerow(['method_no', 'index', 't1', 't1_var', 't1_type', 't2', 't2_var', 't2_type',
                        't3', 't3_var', 't3_type'])
        decl_js = json.load(open(self.decl_path + self.project + '.json'))
        for directory, sub_dirs, files in os.walk(self.method_path, topdown=False):
            for name in files:
                if name.endswith('.id'):
                    t = threading.Thread(target=self.gen_trigram_worker, args=(name, decl_js, f_csv, directory, lock))
                    threads.append(t)
                    t.start()
        [t.join() for t in threads]
        f.close()
        df = pd.read_csv(self.trigram_path + self.project + '.csv')
        df = df[(df['t1_var'] != 0) | (df['t2_var'] != 0) | (df['t1_var'] != 0)]
        for token in ['t1', 't2', 't3']:
            left_tokens = list({'t1', 't2', 't3'} - {token})
            df.loc[:, token + '_rec'] = None
            df.loc[:, token + '_rec'][(df[token] == df[left_tokens[0]]) & (df[token] != df[left_tokens[1]])] = \
                left_tokens[
                    0]
            df.loc[:, token + '_rec'][(df[token] != df[left_tokens[0]]) & (df[token] == df[left_tokens[1]])] = \
                left_tokens[
                    1]
            df.loc[:, token + '_rec'][(df[token] == df[left_tokens[0]]) & (df[token] == df[left_tokens[1]])] = 'all'
            df.loc[:, token + '_rec'][(df[token] != df[left_tokens[0]]) & (df[token] != df[left_tokens[1]])] = 'none'
        df.to_csv(self.trigram_path + self.project + '.csv', index=None)

    def group_process(self, group):
        group_df = group[group[self.rest + '_var'] == 1]
        group.loc[(group[self.rest + '_rec'] == self.indicator) & group[self.rest + '_var'] == 1,
                  self.rest + '_tks'] = str(group_df[self.rest].tolist())
        group.loc[(group[self.rest + '_rec'] == self.indicator) & group[self.rest + '_var'] == 1,
                  self.rest + '_tk_types'] = str(group_df[self.rest + '_type'].tolist())
        group.loc[(group[self.rest + '_rec'] == self.indicator) & group[self.rest + '_var'] == 1,
                  self.rest + '_mtd_no'] = str(group_df['method_no'].tolist())
        return group

    # Check likelihood
    def check_likelihood(self):
        df = pd.read_csv(self.trigram_path + self.project + '.csv')
        for token in ['t1', 't2', 't3']:
            df[token + '_tks'] = None
            df[token + '_tk_types'] = None
            df[token + '_mtd_no'] = None
            left_tokens = list({'t1', 't2', 't3'} - {token})
            rec_indicators = ['none', left_tokens[0], left_tokens[1], 'all']

            self.rest = token
            for rec_indicator in rec_indicators:
                self.indicator = rec_indicator
                if rec_indicator == 'all':
                    group_all = df[df[token + '_rec'] == 'all']
                    df.loc[df[token + '_rec'] == 'all', token + '_tks'] = str(group_all[token].tolist())
                    df.loc[df[token + '_rec'] == 'all', token + '_tk_types'] = str(group_all[token + '_type'].tolist())
                    df.loc[df[token + '_rec'] == 'all', token + '_mtd_no'] = str(group_all['method_no'].tolist())
                else:
                    if rec_indicator != 'none':
                        group_tokens = list(set(left_tokens) - {rec_indicator})[0]
                    else:
                        group_tokens = left_tokens
                    df[df[token + '_rec'] == rec_indicator] = \
                        df[df[token + '_rec'] == rec_indicator].groupby(group_tokens).apply(self.group_process)
        frames = []
        for token in ['t1', 't2', 't3']:
            frames.append(df[['method_no', 'index', token, token + '_var', token + '_type', token + '_tks',
                              token + '_tk_types',
                              token + '_mtd_no']].rename(index=str, columns={token: 'token', token + '_var': 'is_var',
                                                                             token + '_type': 'type',
                                                                             token + '_tks': 'candidates',
                                                                             token + '_tk_types': 'cand_types',
                                                                             token + '_mtd_no': 'in_methods'}))
        df = pd.concat(frames)
        df = df[(df['is_var'] == 1) & (df['candidates'].notnull()) & (df['candidates'] != '[]')]
        df.to_csv(self.result_path + self.project + '.csv', index=None)

    def find_synonyms_for_token(self, row):
        candidates = ast.literal_eval(row['candidates'])
        types = ast.literal_eval(row['cand_types'])
        method_nos = ast.literal_eval(row['in_methods'])
        forbidden_list = set(list(self.decl_js[str(int(row['method_no']))].keys()) + \
                             self.class_js[str(self.meta_js[str(int(row['method_no']))]['class_index'])]['vars']) - {
                         row['token']}
        indexes = [i for i, x in enumerate(types) if (x == row['type']) and
                   (candidates[i] not in list(forbidden_list)) and
                   (method_nos[i] != row['method_no'])]
        candidates = [candidates[x] for x in indexes]
        cands = []
        counts = []
        pers = []
        counter = Counter(candidates)
        for item in counter:
            cands.append(item)
            counts.append(counter[item])
            pers.append(counter[item] / len(indexes))
        if len(cands) == 0:
            row['cands'] = None
        else:
            row['cands'] = cands
        row['cnts'] = counts
        row['pers'] = pers
        return row

    def find_synonyms_for_method(self, group):
        group.groupby('token').apply(self.find_synonyms_for_token)
        return group

    # suggest renaming
    def give_synonyms(self):
        self.meta_js = json.load(open(self.meta_path + self.project + '.json'))
        self.decl_js = json.load(open(self.decl_path + self.project + '.json'))
        self.class_js = json.load(open(self.decl_path + self.project + '_class.json'))
        recommendations = []
        result_df = pd.read_csv(self.result_path + self.project + '.csv')
        result_df = result_df.apply(self.find_synonyms_for_token, axis=1)
        result_df = result_df[result_df['cands'].notnull()]
        del result_df['candidates'], result_df['cand_types'], result_df['is_var']
        for name, group in result_df.groupby(['method_no', 'token']):
            cands = group['cands'].sum()
            cnts = group['cnts'].sum()
            pers = group['pers'].sum()
            # print(cands, cnts, pers)
            cnt_sum = sum(cnts)
            per_sum = sum(pers)
            if per_sum != 0:
                for item in set(cands):
                    indexes = [i for i, x in enumerate(cands) if x == item]
                    prob = sum([pers[x] for x in indexes]) / per_sum
                    meta_info = self.meta_js[str(int(name[0]))]
                    rec = [meta_info['file_path'], meta_info['class_name'], meta_info['method_path'], name[1], item,
                           cnt_sum, prob]
                    recommendations.append(rec)
        with open(self.result_path + self.project + '_rec' + '.csv', 'w') as f:
            csv_file = csv.writer(f)
            csv_file.writerow(['file', 'class', 'method', 'variable', 'suggestion', 'C_c (reliability)',
                               'C_p (confidence)'])
            csv_file.writerows(recommendations)
        df = pd.read_csv(self.result_path + self.project + '_rec' + '.csv')
        df = df.sort_values('C_p (confidence)', ascending=False)
        df = df.drop_duplicates(subset=['file', 'class', 'method', 'variable'], keep='first')
        df = df[(df['variable'] != df['suggestion']) & (df['C_p (confidence)'] > 0.5) & (df['C_c (reliability)'] >= 5)]
        df.to_csv(self.result_path + self.project + '_rec' + '.csv', index=None)

    # Process
    def process(self):
        print('parsing to xml (1/7)')
        self.parse_to_xml()
        print('extracting variables (2/7)')
        self.extract_methods_variables()
        print('generating tokens (3/7)')
        self.gen_tokens()
        print('generating identifiers (4/7)')
        self.gen_identifiers_wo_method()
        print('generating trigrams (5/7)')
        self.gen_trigrams()
        print('checking likelihood (6/7)\nIt will take a while.')
        self.check_likelihood()
        print('generating suggestions (7/7)\nIt will take a while.')
        self.give_synonyms()
        print('finished!')
